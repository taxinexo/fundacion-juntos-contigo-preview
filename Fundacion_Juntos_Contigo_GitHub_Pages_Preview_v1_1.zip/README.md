# Vista previa Fundación Juntos Contigo

Prototipo visual sin formularios, reservas o donaciones activas. No modificar el sitio productivo.

GitHub Pages: Settings → Pages → Deploy from a branch → main / (root).

Mantener esta versión en repositorio independiente; `noindex` es complementario, no una protección de acceso.
